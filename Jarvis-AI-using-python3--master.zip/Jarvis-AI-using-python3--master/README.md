# Jarvis-AI-using-python3

# Modules requires:
            import pyttsx3  #pip install pyttsx3
            import datetime  #module
            import speech_recognition as sr
            import wikipedia
            import smtplib
            import webbrowser as wb
            import os  #inbuilt
            import pyautogui
            import psutil  #pip install psutil
            import pyjokes  # pip install pyjokes
            import requests, json  #inbuilt


This is the New Jarvis AI Project it will do some functionality followed by user query.

Say "Help" or "tell me your features" , it will show all it's features

# This AI can do:
            it can help to do lot many things like..
            it can tell you the current time and date,
            it can tell you the current weather,
            it can tell you battery and cpu usage,
            it can create the reminder list,
            it can take screenshots,
            it can send email to your boss or family or your friend,
            it can shut down or logout or hibernate your system,
            it can tell you non funny jokes, :)
            it can open any website, on chrome web-browser
            it can search the thing on wikipedia,
            it can change his/her voice from male to female and vice-versa
            And yes  more thing to come...
            
# If you like it leave a Star * on this Repo

![image](https://user-images.githubusercontent.com/11313549/83199718-64016700-a15f-11ea-8d7e-9b04280841f9.png)

![image](https://user-images.githubusercontent.com/11313549/83199495-ed646980-a15e-11ea-8834-d193af78e21d.png)
            
![image](https://user-images.githubusercontent.com/11313549/83199419-c312ac00-a15e-11ea-865c-54bfebae78bb.png)


